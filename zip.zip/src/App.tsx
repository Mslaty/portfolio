import { Routes, Route } from 'react-router-dom'
import Landing from './pages/Landing'
import OcrTool from './pages/OcrTool'
import ChatDemo from './pages/ChatDemo'
import PipelineDemo from './pages/PipelineDemo'
import DashboardDemo from './pages/DashboardDemo'
import ApiDemo from './pages/ApiDemo'
import KanbanDemo from './pages/KanbanDemo'
import Navbar from './components/Navbar'

export default function App() {
  return (
    <div className="app">
      <Navbar />
      <Routes>
        <Route path="/" element={<Landing />} />
        <Route path="/ocr" element={<OcrTool />} />
        <Route path="/chat" element={<ChatDemo />} />
        <Route path="/pipeline" element={<PipelineDemo />} />
        <Route path="/dashboard" element={<DashboardDemo />} />
        <Route path="/api" element={<ApiDemo />} />
        <Route path="/kanban" element={<KanbanDemo />} />
      </Routes>
    </div>
  )
}
