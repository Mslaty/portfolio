import { useState, useEffect } from 'react'
import { Plus, X, GripVertical } from 'lucide-react'

interface Task { id: string; title: string; tag: string }
type Column = 'backlog' | 'todo' | 'progress' | 'done'

const COLUMN_META: { id: Column; label: string; color: string }[] = [
  { id: 'backlog', label: 'Backlog', color: '#8888a0' },
  { id: 'todo', label: 'To Do', color: '#6c63ff' },
  { id: 'progress', label: 'En Progreso', color: '#f59e0b' },
  { id: 'done', label: 'Hecho', color: '#22c55e' },
]

const TAGS = ['feature', 'bug', 'mejora', 'docs', 'test']
const TAG_COLORS: Record<string, string> = { feature: '#6c63ff', bug: '#ef4444', mejora: '#22c55e', docs: '#8888a0', test: '#f59e0b' }

const DEFAULT_TASKS: Record<Column, Task[]> = {
  backlog: [
    { id: 't1', title: 'Integrar WebSocket para notificaciones en tiempo real', tag: 'feature' },
    { id: 't2', title: 'Anadir tests E2E con Playwright', tag: 'test' },
  ],
  todo: [
    { id: 't3', title: 'Configurar SonarQube en pipeline CI/CD', tag: 'mejora' },
    { id: 't4', title: 'Fix: paginacion no resetea al cambiar filtro', tag: 'bug' },
  ],
  progress: [
    { id: 't5', title: 'Dashboard de metricas con React Query', tag: 'feature' },
  ],
  done: [
    { id: 't6', title: 'Setup proyecto con Vite + Tailwind', tag: 'mejora' },
    { id: 't7', title: 'CRUD de productos con Redux', tag: 'feature' },
    { id: 't8', title: 'Documentar endpoints de la API REST', tag: 'docs' },
  ],
}

const LS_KEY = 'portfolio_kanban'
let nextId = 100

function loadState(): Record<Column, Task[]> {
  try {
    const saved = localStorage.getItem(LS_KEY)
    if (saved) return JSON.parse(saved)
  } catch { /* ignore */ }
  return DEFAULT_TASKS
}

export default function KanbanDemo() {
  const [columns, setColumns] = useState(loadState)
  const [dragItem, setDragItem] = useState<{ task: Task; from: Column } | null>(null)
  const [dragOver, setDragOver] = useState<Column | null>(null)
  const [adding, setAdding] = useState<Column | null>(null)
  const [newTitle, setNewTitle] = useState('')
  const [newTag, setNewTag] = useState('feature')

  useEffect(() => { localStorage.setItem(LS_KEY, JSON.stringify(columns)) }, [columns])

  const handleDrop = (to: Column) => {
    if (!dragItem || dragItem.from === to) { setDragItem(null); setDragOver(null); return }
    setColumns(prev => ({
      ...prev,
      [dragItem.from]: prev[dragItem.from].filter(t => t.id !== dragItem.task.id),
      [to]: [...prev[to], dragItem.task],
    }))
    setDragItem(null); setDragOver(null)
  }

  const addTask = (col: Column) => {
    if (!newTitle.trim()) return
    setColumns(prev => ({ ...prev, [col]: [...prev[col], { id: `t${++nextId}`, title: newTitle.trim(), tag: newTag }] }))
    setNewTitle(''); setAdding(null)
  }

  const deleteTask = (col: Column, id: string) => {
    setColumns(prev => ({ ...prev, [col]: prev[col].filter(t => t.id !== id) }))
  }

  const resetBoard = () => { setColumns(DEFAULT_TASKS); localStorage.removeItem(LS_KEY) }

  const totalTasks = Object.values(columns).reduce((s, c) => s + c.length, 0)
  const doneTasks = columns.done.length

  return (
    <div className="max-w-6xl mx-auto p-6">
      <div className="flex justify-between items-start mb-6 flex-wrap gap-3">
        <div>
          <h1 className="text-2xl font-bold mb-1">Gestor de Tareas Kanban</h1>
          <p className="text-muted">
            Arrastra tareas entre columnas &middot; {doneTasks}/{totalTasks} completadas &middot; Se guarda en localStorage
          </p>
        </div>
        <button onClick={resetBoard} className="text-xs text-muted border border-border rounded-lg px-3 py-1.5 hover:text-white hover:border-muted transition-colors">
          Reset tablero
        </button>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {COLUMN_META.map(col => (
          <div
            key={col.id}
            className={`bg-card border rounded-xl min-h-[300px] transition-all ${dragOver === col.id ? 'border-accent shadow-[0_0_15px_var(--color-accent-glow)]' : 'border-border'}`}
            onDragOver={e => { e.preventDefault(); setDragOver(col.id) }}
            onDragLeave={() => setDragOver(null)}
            onDrop={() => handleDrop(col.id)}
          >
            {/* Column header */}
            <div className="flex items-center gap-2 px-3 py-2.5 border-b border-border">
              <span className="w-2 h-2 rounded-full" style={{ background: col.color }} />
              <h3 className="text-sm font-semibold flex-1">{col.label}</h3>
              <span className="text-[0.7rem] bg-white/[0.06] px-1.5 py-0.5 rounded-full text-muted">{columns[col.id].length}</span>
            </div>

            {/* Tasks */}
            <div className="p-2 flex flex-col gap-1.5">
              {columns[col.id].map(task => (
                <div
                  key={task.id}
                  draggable
                  onDragStart={() => setDragItem({ task, from: col.id })}
                  className="group flex items-start gap-1.5 p-2.5 bg-bg border border-border rounded-lg cursor-grab active:cursor-grabbing active:opacity-70 hover:border-accent transition-all"
                >
                  <GripVertical size={14} className="text-muted/30 shrink-0 mt-0.5" />
                  <div className="flex-1 min-w-0">
                    <span className="inline-block text-[0.6rem] font-semibold uppercase tracking-wide px-1.5 py-px rounded-full text-white mb-1" style={{ background: TAG_COLORS[task.tag] || '#888' }}>
                      {task.tag}
                    </span>
                    <p className="text-xs leading-snug">{task.title}</p>
                  </div>
                  <button onClick={() => deleteTask(col.id, task.id)} className="opacity-0 group-hover:opacity-50 hover:!opacity-100 hover:text-red-400 text-muted transition-all p-0.5">
                    <X size={12} />
                  </button>
                </div>
              ))}

              {/* Add task */}
              {adding === col.id ? (
                <div className="flex flex-col gap-1.5 p-2 border border-accent rounded-lg bg-bg">
                  <input
                    autoFocus
                    placeholder="Titulo..."
                    value={newTitle}
                    onChange={e => setNewTitle(e.target.value)}
                    onKeyDown={e => { if (e.key === 'Enter') addTask(col.id); if (e.key === 'Escape') setAdding(null) }}
                    className="px-2 py-1.5 rounded bg-card border border-border text-white text-xs focus:outline-none focus:border-accent"
                  />
                  <select value={newTag} onChange={e => setNewTag(e.target.value)} className="px-2 py-1 rounded bg-card border border-border text-white text-xs focus:outline-none focus:border-accent">
                    {TAGS.map(t => <option key={t} value={t}>{t}</option>)}
                  </select>
                  <div className="flex gap-1.5">
                    <button onClick={() => addTask(col.id)} className="flex-1 px-2 py-1 rounded bg-accent text-white text-xs font-medium hover:bg-accent-hover transition-colors">Anadir</button>
                    <button onClick={() => setAdding(null)} className="px-2 py-1 rounded border border-border text-xs text-muted hover:text-white transition-colors">Cancelar</button>
                  </div>
                </div>
              ) : (
                <button
                  onClick={() => { setAdding(col.id); setNewTitle(''); setNewTag('feature') }}
                  className="flex items-center justify-center gap-1 w-full py-2 border border-dashed border-border rounded-lg text-xs text-muted hover:border-accent hover:text-accent transition-all"
                >
                  <Plus size={14} /> Anadir tarea
                </button>
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}
