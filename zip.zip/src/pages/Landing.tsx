import { Link } from 'react-router-dom'
import ProjectCard from '../components/ProjectCard'
import { Mail, Phone, MapPin, ArrowRight, Workflow, Database, BarChart3, Bot, Globe, Server } from 'lucide-react'

const projects = [
  {
    tag: 'IA / OCR',
    title: 'Extractor de Facturas OCR',
    description: 'Herramienta de vision por IA que extrae columnas configurables de facturas PDF. Prompt dinamico, previsualizacion del documento y exportacion a CSV.',
    tech: ['React', 'TypeScript', 'Vite', 'Gemini Vision API', 'REST'],
    demoPath: '/ocr',
  },
  {
    tag: 'Chat Agentes / WebSocket',
    title: 'Panel de Chat Multi-Agente',
    description: 'Interfaz de chat en tiempo real conectada a agentes de IA con personalidades distintas. Comunicacion via API, historial persistente y selector de agente.',
    tech: ['React', 'TypeScript', 'Tailwind CSS', 'Gemini API', 'Node.js', 'Express'],
    demoPath: '/chat',
  },
  {
    tag: 'Automatizacion / ETL',
    title: 'Pipeline de Datos CRM',
    description: 'Flujo ETL que procesa datos de ventas: validacion, normalizacion, calculo de margenes y generacion de informe. Con dataset real de prueba incluido.',
    tech: ['N8N', 'Python', 'REST API', 'SQL', 'PostgreSQL', 'Docker'],
    demoPath: '/pipeline',
  },
  {
    tag: 'Datos / BI',
    title: 'Dashboard de Ventas',
    description: 'Dashboard interactivo con KPIs, graficos de barras y ranking de productos. Filtros dinamicos por categoria y region que recalculan todo en tiempo real.',
    tech: ['PowerBI', 'DAX', 'M', 'SQL', 'Python', 'REST API'],
    demoPath: '/dashboard',
  },
  {
    tag: 'Backend / API',
    title: 'API REST con RBAC',
    description: 'Explorador de API interactivo con CRUD real en memoria. Autenticacion JWT, control de roles (admin/editor/viewer) y rate limiting funcional.',
    tech: ['FastAPI', 'Python', 'PostgreSQL', 'Docker', 'Ubuntu', 'JWT'],
    demoPath: '/api',
  },
  {
    tag: 'Frontend / React',
    title: 'Gestor de Tareas Kanban',
    description: 'Tablero Kanban con drag-and-drop real, crear/editar/borrar tareas, tags por tipo y persistencia en localStorage.',
    tech: ['React', 'TypeScript', 'Tailwind CSS', 'Redux', 'React Query', 'Vitest'],
    demoPath: '/kanban',
  },
]

const techCategories = [
  { title: 'Frontend', icon: Globe, items: ['React', 'TypeScript', 'Tailwind CSS', 'Vite', 'Next.js', 'HTML/CSS', 'Three.js'] },
  { title: 'Backend & APIs', icon: Server, items: ['Node.js', 'Express', 'FastAPI', 'Python', 'WebSocket', 'REST API'] },
  { title: 'Datos & BI', icon: BarChart3, items: ['SQL', 'PostgreSQL', 'PowerBI', 'DAX / M', 'SQLite'] },
  { title: 'IA & Agentes', icon: Bot, items: ['Gemini API', 'OpenAI / GPT', 'Chat Agentes', 'OCR Vision', 'N8N'] },
  { title: 'DevOps & QA', icon: Workflow, items: ['Docker', 'GitHub Flow', 'Vitest', 'Ubuntu', 'SonarQube', 'CI/CD'] },
  { title: 'Integraciones', icon: Database, items: ['APIs REST', 'WebSocket', 'ETL', 'CRM', 'Automatizacion'] },
]

export default function Landing() {
  return (
    <>
      {/* Hero */}
      <section className="text-center py-20 px-6 max-w-3xl mx-auto">
        <h1 className="text-5xl font-extrabold leading-tight mb-4 bg-gradient-to-r from-white to-accent bg-clip-text text-transparent">
          Desarrollo Full-Stack & Soluciones IA
        </h1>
        <p className="text-lg text-muted max-w-xl mx-auto">
          Automatizacion con inteligencia artificial, integracion de sistemas
          y desarrollo web orientado a producto.
        </p>
        <div className="flex gap-3 justify-center mt-8">
          <a href="#proyectos" className="inline-flex items-center gap-2 px-5 py-2.5 rounded-lg font-medium bg-accent text-white hover:bg-accent-hover transition-colors no-underline">
            Ver proyectos <ArrowRight size={16} />
          </a>
          <a href="#contacto" className="inline-flex items-center gap-2 px-5 py-2.5 rounded-lg font-medium border border-border text-white hover:bg-white/5 transition-colors no-underline">
            Contactar
          </a>
        </div>
      </section>

      {/* About */}
      <section className="max-w-5xl mx-auto px-6 pt-16 pb-8 scroll-mt-20" id="sobre-mi">
        <div className="grid grid-cols-1 md:grid-cols-[1.4fr_1fr] gap-8">
          <div>
            <h2 className="text-2xl font-bold mb-4">Sobre mi</h2>
            <p className="text-muted text-[0.95rem] leading-relaxed mb-3">
              Profesional proactivo orientado a la resolucion de problemas, con base solida
              en automatizacion y analisis de datos.
            </p>
            <p className="text-muted text-[0.95rem] leading-relaxed mb-3">
              Experiencia en integracion de sistemas mediante APIs, flujos ETL con n8n,
              reporting con PowerBI y desarrollo full-stack con React, Node.js y Python.
            </p>
            <p className="text-muted text-[0.95rem] leading-relaxed mb-3">
              Trayectoria previa en gestion de equipos en hosteleria de alto nivel
              (Melia ME Madrid, Mandarin Oriental Barcelona, Livvo Lumm Las Palmas)
              con gran capacidad de organizacion y trabajo bajo presion.
            </p>
            <div className="flex gap-6 mt-6">
              {[{ n: '6+', l: 'Proyectos full-stack' }, { n: 'ETL', l: 'Flujos automatizados' }, { n: 'IA', l: 'Agentes & OCR' }].map(h => (
                <div key={h.n} className="text-center">
                  <span className="text-2xl font-extrabold text-accent block">{h.n}</span>
                  <span className="text-xs text-muted">{h.l}</span>
                </div>
              ))}
            </div>
          </div>

          <div className="bg-card border border-border rounded-xl p-5">
            <h3 className="font-semibold mb-4">Metodologia & Herramientas</h3>
            <ul className="space-y-2.5">
              {[
                ['Scrum', 'Sprints, dailies, retrospectivas'],
                ['GitHub Flow', 'Feature branches, PRs, code review'],
                ['Testing', 'Vitest (unitario), Playwright (E2E)'],
                ['Calidad', 'SonarQube para analisis estatico'],
                ['CI/CD', 'GitHub Actions, Docker, Vercel'],
              ].map(([title, desc]) => (
                <li key={title} className="text-sm text-muted pl-4 relative before:content-[''] before:absolute before:left-0 before:top-[0.55em] before:w-1.5 before:h-1.5 before:rounded-full before:bg-accent">
                  <strong className="text-white">{title}</strong> &mdash; {desc}
                </li>
              ))}
            </ul>
          </div>
        </div>
      </section>

      {/* Stack */}
      <section className="max-w-5xl mx-auto px-6 py-8">
        <h2 className="text-xl font-semibold text-muted mb-5">Stack tecnologico</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {techCategories.map(cat => (
            <div key={cat.title} className="bg-card border border-border rounded-xl p-4 hover:border-accent transition-colors">
              <div className="flex items-center gap-2 text-accent mb-3">
                <cat.icon size={20} />
                <h3 className="text-sm font-semibold text-white">{cat.title}</h3>
              </div>
              <div className="flex flex-wrap gap-1.5">
                {cat.items.map(item => (
                  <span key={item} className="text-xs px-2 py-0.5 rounded-md bg-white/[0.04] text-muted border border-border">{item}</span>
                ))}
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Projects */}
      <section className="max-w-5xl mx-auto px-6 py-8 scroll-mt-20" id="proyectos">
        <h2 className="text-xl font-semibold text-muted mb-5">Proyectos destacados</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {projects.map(p => <ProjectCard key={p.title} {...p} />)}
        </div>
        <div className="text-center mt-8">
          <Link to="/ocr" className="inline-flex items-center gap-2 px-5 py-2.5 rounded-lg font-medium bg-accent text-white hover:bg-accent-hover transition-colors no-underline">
            Probar demo OCR <ArrowRight size={16} />
          </Link>
        </div>
      </section>

      {/* Contact */}
      <section className="max-w-5xl mx-auto px-6 pt-16 pb-8 scroll-mt-20" id="contacto">
        <div className="grid grid-cols-1 md:grid-cols-[1.5fr_1fr] gap-8">
          <div>
            <h2 className="text-2xl font-bold mb-2">Contactame</h2>
            <p className="text-muted mb-6">Disponible para oportunidades de desarrollo frontend/full-stack.</p>
            <div className="flex flex-col gap-3 mb-6">
              <a href="mailto:msuarezlaty@gmail.com" className="flex items-center gap-2.5 text-sm text-muted hover:text-accent transition-colors no-underline">
                <Mail size={18} /> msuarezlaty@gmail.com
              </a>
              <a href="tel:+34627455648" className="flex items-center gap-2.5 text-sm text-muted hover:text-accent transition-colors no-underline">
                <Phone size={18} /> 627 455 648
              </a>
              <div className="flex items-center gap-2.5 text-sm text-muted">
                <MapPin size={18} /> Las Palmas de Gran Canaria
              </div>
            </div>
          </div>

          <div className="bg-card border border-border rounded-xl p-5 flex flex-col gap-4 items-start">
            <div className="flex items-center gap-2 font-medium">
              <span className="w-2.5 h-2.5 rounded-full bg-green-500 shadow-[0_0_8px_rgba(34,197,94,0.5)] animate-pulse-dot" />
              Disponible para incorporacion
            </div>
          </div>
        </div>
      </section>

      <footer className="text-center py-12 text-sm text-muted border-t border-border mt-16">
        &copy; {new Date().getFullYear()} &middot; M. Suarez &middot; Desarrollo Web & IA
      </footer>
    </>
  )
}
