import { useState, useRef, useEffect, useCallback } from 'react'
import { Play, RotateCcw, CheckCircle, XCircle, Clock, ArrowRight, Download } from 'lucide-react'

/* ─── Embedded sample dataset (sales CSV) ─── */
const RAW_CSV = `fecha;producto;codigo;cantidad;precio;descuento;region;vendedor
15/01/2024;Monitor 27" 4K;MON-001;3;279.99;5;Canarias;Ana Lopez
15/01/2024;Teclado Mecanico RGB;TEC-042;;79.90;0;Peninsula;Carlos Ruiz
16/01/2024;Auriculares BT Pro;AUR-015;2;89.50;10;Baleares;Ana Lopez
16/01/2024;Hub USB-C 7p;HUB-008;5;59.99;0;Canarias;Maria Diaz
17/01/2024;Webcam HD 1080p;WEB-003;1;-45.00;0;Peninsula;Carlos Ruiz
17/01/2024;Monitor 27" 4K;MON-001;2;279.99;15;Canarias;Ana Lopez
18/01/2024;Teclado Mecanico RGB;TEC-042;4;79.90;0;Baleares;
19/01/2024;SSD 1TB NVMe;SSD-100;3;109.95;5;Peninsula;Maria Diaz
19/01/2024;Auriculares BT Pro;AUR-015;1;89.50;0;Canarias;Carlos Ruiz
20/01/2024;Monitor 27" 4K;MON-001;abc;279.99;0;Peninsula;Ana Lopez`

type StepId = 'raw' | 'validate' | 'transform' | 'load' | 'report'
type StepStatus = 'idle' | 'running' | 'done' | 'error'

interface Row { [key: string]: string }
interface ValidatedRow extends Row { _valid: string; _errors: string }
interface TransformedRow extends Row { importe_bruto: string; importe_neto: string; margen_est: string }

function parseCSV(csv: string): Row[] {
  const lines = csv.trim().split('\n')
  const headers = lines[0].split(';').map(h => h.trim())
  return lines.slice(1).map(line => {
    const vals = line.split(';')
    const row: Row = {}
    headers.forEach((h, i) => { row[h] = (vals[i] || '').trim() })
    return row
  })
}

function validateRows(rows: Row[]): ValidatedRow[] {
  return rows.map(row => {
    const errors: string[] = []
    if (!row.cantidad || isNaN(Number(row.cantidad)) || Number(row.cantidad) <= 0) errors.push('cantidad invalida')
    if (!row.precio || isNaN(Number(row.precio)) || Number(row.precio) <= 0) errors.push('precio invalido')
    if (!row.vendedor) errors.push('vendedor vacio')
    if (!row.fecha) errors.push('fecha vacia')
    return { ...row, _valid: errors.length === 0 ? 'si' : 'no', _errors: errors.join(', ') || '-' }
  })
}

function transformRows(rows: ValidatedRow[]): TransformedRow[] {
  return rows
    .filter(r => r._valid === 'si')
    .map(row => {
      const cant = Number(row.cantidad)
      const precio = Number(row.precio)
      const dto = Number(row.descuento) || 0
      const bruto = cant * precio
      const neto = bruto * (1 - dto / 100)
      const margen = neto * 0.35 // estimated 35% margin
      return {
        ...row,
        fecha: row.fecha.split('/').reverse().join('-'), // DD/MM/YYYY -> YYYY-MM-DD
        importe_bruto: bruto.toFixed(2),
        importe_neto: neto.toFixed(2),
        margen_est: margen.toFixed(2),
      }
    })
}

function generateReport(rows: TransformedRow[]) {
  const totalNeto = rows.reduce((s, r) => s + Number(r.importe_neto), 0)
  const totalMargen = rows.reduce((s, r) => s + Number(r.margen_est), 0)
  const byRegion: Record<string, number> = {}
  const byVendedor: Record<string, number> = {}
  rows.forEach(r => {
    byRegion[r.region] = (byRegion[r.region] || 0) + Number(r.importe_neto)
    byVendedor[r.vendedor] = (byVendedor[r.vendedor] || 0) + Number(r.importe_neto)
  })
  return { totalNeto, totalMargen, totalRows: rows.length, byRegion, byVendedor }
}

interface LogEntry { time: string; step: string; msg: string; type: 'info' | 'success' | 'error' | 'warn' }
function ts() { return new Date().toLocaleTimeString('es-ES', { hour: '2-digit', minute: '2-digit', second: '2-digit' }) }

const STEPS: { id: StepId; label: string; duration: number }[] = [
  { id: 'raw', label: 'Cargar datos', duration: 800 },
  { id: 'validate', label: 'Validar', duration: 1200 },
  { id: 'transform', label: 'Transformar', duration: 1800 },
  { id: 'load', label: 'Cargar en CRM', duration: 1000 },
  { id: 'report', label: 'Informe', duration: 600 },
]

export default function PipelineDemo() {
  const [statuses, setStatuses] = useState<Record<string, StepStatus>>({})
  const [running, setRunning] = useState(false)
  const [logs, setLogs] = useState<LogEntry[]>([])
  const [activeStep, setActiveStep] = useState<StepId | null>(null)
  const [rawRows, setRawRows] = useState<Row[]>([])
  const [validatedRows, setValidatedRows] = useState<ValidatedRow[]>([])
  const [transformedRows, setTransformedRows] = useState<TransformedRow[]>([])
  const [report, setReport] = useState<ReturnType<typeof generateReport> | null>(null)
  const logRef = useRef<HTMLDivElement>(null)

  const scrollLog = useCallback(() => { if (logRef.current) logRef.current.scrollTop = logRef.current.scrollHeight }, [])
  useEffect(scrollLog, [logs, scrollLog])

  const addLog = useCallback((step: string, msg: string, type: LogEntry['type'] = 'info') => {
    setLogs(prev => [...prev, { time: ts(), step, msg, type }])
  }, [])

  const run = useCallback(async () => {
    setRunning(true); setLogs([]); setStatuses({}); setActiveStep(null)
    setRawRows([]); setValidatedRows([]); setTransformedRows([]); setReport(null)

    addLog('pipeline', 'Iniciando pipeline ETL...', 'info')

    // Step 1: Parse raw
    setStatuses(s => ({ ...s, raw: 'running' })); setActiveStep('raw')
    addLog('Cargar', `Parseando CSV: ${RAW_CSV.split('\n').length - 1} filas`, 'info')
    await new Promise(r => setTimeout(r, 800))
    const raw = parseCSV(RAW_CSV)
    setRawRows(raw)
    setStatuses(s => ({ ...s, raw: 'done' }))
    addLog('Cargar', `${raw.length} registros cargados`, 'success')

    // Step 2: Validate
    setStatuses(s => ({ ...s, validate: 'running' })); setActiveStep('validate')
    addLog('Validar', 'Validando campos obligatorios, tipos y rangos...', 'info')
    await new Promise(r => setTimeout(r, 1200))
    const validated = validateRows(raw)
    setValidatedRows(validated)
    const valid = validated.filter(r => r._valid === 'si').length
    const invalid = validated.length - valid
    setStatuses(s => ({ ...s, validate: 'done' }))
    addLog('Validar', `${valid} validos, ${invalid} descartados`, invalid > 0 ? 'warn' : 'success')
    validated.filter(r => r._valid === 'no').forEach(r => addLog('Validar', `Descartado: ${r.producto} → ${r._errors}`, 'error'))

    // Step 3: Transform
    setStatuses(s => ({ ...s, transform: 'running' })); setActiveStep('transform')
    addLog('Transformar', 'Normalizando fechas, calculando importes y margenes...', 'info')
    await new Promise(r => setTimeout(r, 1800))
    const transformed = transformRows(validated)
    setTransformedRows(transformed)
    setStatuses(s => ({ ...s, transform: 'done' }))
    addLog('Transformar', `${transformed.length} filas transformadas`, 'success')

    // Step 4: Load
    setStatuses(s => ({ ...s, load: 'running' })); setActiveStep('load')
    addLog('Cargar CRM', `INSERT INTO crm.ventas ... ${transformed.length} filas`, 'info')
    await new Promise(r => setTimeout(r, 1000))
    setStatuses(s => ({ ...s, load: 'done' }))
    addLog('Cargar CRM', 'Carga completada', 'success')

    // Step 5: Report
    setStatuses(s => ({ ...s, report: 'running' })); setActiveStep('report')
    await new Promise(r => setTimeout(r, 600))
    const rep = generateReport(transformed)
    setReport(rep)
    setStatuses(s => ({ ...s, report: 'done' })); setActiveStep('report')
    addLog('Informe', `Total neto: ${rep.totalNeto.toFixed(2)}€, Margen: ${rep.totalMargen.toFixed(2)}€`, 'success')
    addLog('pipeline', 'Pipeline finalizado con exito.', 'success')
    setRunning(false)
  }, [addLog])

  const reset = () => { setRunning(false); setStatuses({}); setLogs([]); setActiveStep(null); setRawRows([]); setValidatedRows([]); setTransformedRows([]); setReport(null) }

  const exportCsv = () => {
    if (!transformedRows.length) return
    const keys = ['fecha', 'producto', 'codigo', 'cantidad', 'precio', 'descuento', 'region', 'vendedor', 'importe_bruto', 'importe_neto', 'margen_est']
    const csv = '\uFEFF' + keys.join(',') + '\n' + transformedRows.map(r => keys.map(k => `"${r[k] || ''}"`).join(',')).join('\n')
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8' })
    const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = 'pipeline_output.csv'; a.click()
  }

  const StatusIcon = ({ s }: { s: StepStatus }) => {
    if (s === 'done') return <CheckCircle size={16} className="text-green-500" />
    if (s === 'error') return <XCircle size={16} className="text-red-500" />
    if (s === 'running') return <div className="w-4 h-4 border-2 border-border border-t-accent rounded-full animate-spin-slow" />
    return <Clock size={16} className="text-muted/40" />
  }

  // Which data to show based on active step
  const tableData = activeStep === 'validate' ? validatedRows
    : (activeStep === 'transform' || activeStep === 'load' || activeStep === 'report') ? transformedRows
    : rawRows

  const tableKeys = activeStep === 'validate'
    ? ['fecha', 'producto', 'cantidad', 'precio', 'vendedor', '_valid', '_errors']
    : (activeStep === 'transform' || activeStep === 'load' || activeStep === 'report')
      ? ['fecha', 'producto', 'cantidad', 'precio', 'region', 'importe_bruto', 'importe_neto', 'margen_est']
      : ['fecha', 'producto', 'codigo', 'cantidad', 'precio', 'descuento', 'region', 'vendedor']

  return (
    <div className="max-w-6xl mx-auto p-6">
      <div className="mb-6">
        <h1 className="text-2xl font-bold mb-1">Pipeline de Datos CRM</h1>
        <p className="text-muted">Flujo ETL con dataset real: extraccion, validacion, transformacion, carga e informe</p>
      </div>

      {/* Controls */}
      <div className="flex gap-3 items-center mb-6 flex-wrap">
        <button onClick={run} disabled={running} className="inline-flex items-center gap-2 px-4 py-2 rounded-lg font-medium bg-accent text-white hover:bg-accent-hover transition-colors disabled:opacity-50">
          <Play size={16} /> Ejecutar pipeline
        </button>
        <button onClick={reset} disabled={running && !report} className="inline-flex items-center gap-2 px-4 py-2 rounded-lg font-medium border border-border text-white hover:bg-white/5 transition-colors disabled:opacity-40">
          <RotateCcw size={16} /> Reset
        </button>
        {transformedRows.length > 0 && (
          <button onClick={exportCsv} className="inline-flex items-center gap-2 px-4 py-2 rounded-lg font-medium border border-border text-white hover:bg-white/5 transition-colors">
            <Download size={16} /> Exportar CSV
          </button>
        )}
      </div>

      {/* Steps */}
      <div className="flex items-start gap-2 overflow-x-auto pb-4 mb-6">
        {STEPS.map((step, i) => (
          <div key={step.id} className="flex items-center gap-2">
            <button
              onClick={() => statuses[step.id] === 'done' && setActiveStep(step.id)}
              className={`flex flex-col items-center gap-1.5 p-4 min-w-[130px] rounded-xl border transition-all text-center ${
                statuses[step.id] === 'running' ? 'border-accent shadow-[0_0_15px_var(--color-accent-glow)]' :
                statuses[step.id] === 'done' ? 'border-green-500/30 cursor-pointer hover:border-green-500' :
                'border-border'
              } bg-card`}
            >
              <StatusIcon s={statuses[step.id] || 'idle'} />
              <strong className="text-xs">{step.label}</strong>
            </button>
            {i < STEPS.length - 1 && <ArrowRight size={18} className="text-muted/30 shrink-0" />}
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-[1fr_350px] gap-4">
        {/* Data table */}
        <div className="bg-card border border-border rounded-xl overflow-hidden">
          <div className="px-4 py-2.5 border-b border-border flex justify-between items-center">
            <h3 className="text-sm font-semibold">
              {activeStep === 'validate' ? 'Validacion' : activeStep === 'transform' || activeStep === 'load' ? 'Datos transformados' : activeStep === 'report' ? 'Datos finales' : 'Datos crudos'}
              {tableData.length > 0 && <span className="text-muted font-normal ml-2">({tableData.length} filas)</span>}
            </h3>
          </div>
          <div className="overflow-x-auto max-h-[400px] overflow-y-auto">
            {tableData.length === 0 ? (
              <p className="text-muted text-sm p-8 text-center">Ejecuta el pipeline para ver los datos</p>
            ) : (
              <table className="w-full text-sm">
                <thead>
                  <tr>{tableKeys.map(k => <th key={k} className="bg-white/[0.03] px-3 py-2 text-left text-xs uppercase tracking-wide text-muted border-b border-border whitespace-nowrap font-semibold">{k}</th>)}</tr>
                </thead>
                <tbody>
                  {tableData.map((row, i) => (
                    <tr key={i} className="hover:bg-white/[0.02]">
                      {tableKeys.map(k => (
                        <td key={k} className={`px-3 py-1.5 border-b border-white/[0.03] whitespace-nowrap ${
                          k === '_valid' && row[k] === 'no' ? 'text-red-400' :
                          k === '_valid' && row[k] === 'si' ? 'text-green-400' :
                          k === '_errors' && row[k] !== '-' ? 'text-red-400 text-xs' :
                          ''
                        }`}>
                          {row[k] || ''}
                        </td>
                      ))}
                    </tr>
                  ))}
                </tbody>
              </table>
            )}
          </div>
        </div>

        {/* Logs + Report */}
        <div className="flex flex-col gap-4">
          {/* Report */}
          {report && (
            <div className="bg-card border border-green-500/30 rounded-xl p-4">
              <h3 className="text-sm font-semibold mb-3 text-green-400">Informe final</h3>
              <div className="grid grid-cols-2 gap-3 text-sm">
                <div><span className="text-muted text-xs block">Filas procesadas</span><strong>{report.totalRows}</strong></div>
                <div><span className="text-muted text-xs block">Total neto</span><strong>{report.totalNeto.toFixed(2)}€</strong></div>
                <div><span className="text-muted text-xs block">Margen estimado</span><strong>{report.totalMargen.toFixed(2)}€</strong></div>
              </div>
              <div className="mt-3 pt-3 border-t border-border">
                <span className="text-muted text-xs block mb-1">Por region</span>
                {Object.entries(report.byRegion).map(([r, v]) => (
                  <div key={r} className="flex justify-between text-xs text-muted"><span>{r}</span><span className="text-white">{v.toFixed(2)}€</span></div>
                ))}
              </div>
              <div className="mt-3 pt-3 border-t border-border">
                <span className="text-muted text-xs block mb-1">Por vendedor</span>
                {Object.entries(report.byVendedor).map(([r, v]) => (
                  <div key={r} className="flex justify-between text-xs text-muted"><span>{r}</span><span className="text-white">{v.toFixed(2)}€</span></div>
                ))}
              </div>
            </div>
          )}

          {/* Logs */}
          <div className="bg-card border border-border rounded-xl overflow-hidden flex-1">
            <div className="flex justify-between px-3 py-2 border-b border-border text-sm">
              <strong>Logs</strong>
              <span className="text-xs text-muted">{logs.length}</span>
            </div>
            <div ref={logRef} className="h-52 overflow-y-auto p-2 font-mono text-xs space-y-0.5">
              {logs.length === 0 && <p className="text-muted text-center py-8 font-sans">Ejecuta el pipeline...</p>}
              {logs.map((l, i) => (
                <div key={i} className={`flex gap-2 px-2 py-0.5 rounded ${l.type === 'error' ? 'text-red-400' : l.type === 'success' ? 'text-green-400' : l.type === 'warn' ? 'text-yellow-400' : 'text-muted'}`}>
                  <span className="text-muted shrink-0">{l.time}</span>
                  <span className="text-accent shrink-0 min-w-[80px]">[{l.step}]</span>
                  <span>{l.msg}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
