import { useState, useRef, useEffect, useCallback } from 'react'
import { Send, Bot, User, Wifi, WifiOff, Trash2, Key, Eye, EyeOff, ExternalLink } from 'lucide-react'

const STORAGE_KEY = 'portfolio_gemini_key'

interface Message {
  id: number
  agent: string
  role: 'user' | 'agent'
  text: string
  time: string
}

const AGENTS = [
  {
    id: 'asistente',
    name: 'Asistente General',
    color: '#22c55e',
    desc: 'Responde preguntas generales',
    system: 'Eres un asistente general amable y conciso. Respondes en espanol. Maximo 2-3 frases por respuesta.',
  },
  {
    id: 'ventas',
    name: 'Agente Ventas',
    color: '#6c63ff',
    desc: 'Analista comercial',
    system: 'Eres un analista comercial experto. Respondes siempre con datos inventados pero realistas sobre ventas, KPIs, conversion y metricas de CRM. Respuestas concisas en espanol, maximo 3 frases. Usa numeros concretos.',
  },
  {
    id: 'soporte',
    name: 'Agente Soporte',
    color: '#f59e0b',
    desc: 'Soporte tecnico DevOps',
    system: 'Eres un ingeniero de soporte DevOps. Respondes sobre servidores, Docker, bases de datos, logs y errores. Respuestas tecnicas y concisas en espanol, maximo 3 frases. Incluye comandos o paths cuando sea relevante.',
  },
]

function now() {
  return new Date().toLocaleTimeString('es-ES', { hour: '2-digit', minute: '2-digit', second: '2-digit' })
}

async function callGemini(apiKey: string, system: string, history: { role: string; text: string }[], userMsg: string): Promise<string> {
  const url = `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=${apiKey}`

  const contents = [
    { role: 'user', parts: [{ text: `INSTRUCCIONES DE SISTEMA: ${system}\n\nResponde al siguiente mensaje del usuario.` }] },
    { role: 'model', parts: [{ text: 'Entendido, seguire esas instrucciones.' }] },
    ...history.map(m => ({
      role: m.role === 'user' ? 'user' : 'model',
      parts: [{ text: m.text }],
    })),
    { role: 'user', parts: [{ text: userMsg }] },
  ]

  const res = await fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      contents,
      generationConfig: { temperature: 0.7, maxOutputTokens: 256 },
    }),
  })

  if (!res.ok) {
    if (res.status === 429) throw new Error('Rate limit. Espera un momento.')
    if (res.status === 403) throw new Error('API key invalida.')
    throw new Error(`Error ${res.status}`)
  }

  const data = await res.json()
  return data.candidates?.[0]?.content?.parts?.[0]?.text || 'Sin respuesta.'
}

export default function ChatDemo() {
  const [apiKey, setApiKey] = useState(() => localStorage.getItem(STORAGE_KEY) || '')
  const [showKey, setShowKey] = useState(false)
  const [activeAgent, setActiveAgent] = useState('asistente')
  const [messages, setMessages] = useState<Message[]>([])
  const [input, setInput] = useState('')
  const [connected, setConnected] = useState(true)
  const [typing, setTyping] = useState(false)
  const scrollRef = useRef<HTMLDivElement>(null)
  const idRef = useRef(0)

  const hasKey = apiKey.trim().length > 0

  const saveKey = () => {
    const t = apiKey.trim()
    if (t) localStorage.setItem(STORAGE_KEY, t)
    else localStorage.removeItem(STORAGE_KEY)
  }

  const scrollToBottom = useCallback(() => {
    if (scrollRef.current) scrollRef.current.scrollTop = scrollRef.current.scrollHeight
  }, [])

  useEffect(scrollToBottom, [messages, typing, scrollToBottom])

  const sendMessage = async () => {
    const text = input.trim()
    if (!text || !connected || typing) return
    if (!hasKey) return

    const userMsg: Message = { id: ++idRef.current, agent: activeAgent, role: 'user', text, time: now() }
    setMessages(prev => [...prev, userMsg])
    setInput('')
    setTyping(true)

    const agent = AGENTS.find(a => a.id === activeAgent)!
    const agentHistory = messages
      .filter(m => m.agent === activeAgent)
      .map(m => ({ role: m.role === 'user' ? 'user' : 'agent', text: m.text }))

    try {
      const response = await callGemini(apiKey.trim(), agent.system, agentHistory, text)
      setMessages(prev => [...prev, { id: ++idRef.current, agent: activeAgent, role: 'agent', text: response, time: now() }])
    } catch (e) {
      setMessages(prev => [...prev, { id: ++idRef.current, agent: activeAgent, role: 'agent', text: `Error: ${e instanceof Error ? e.message : 'Fallo la peticion'}`, time: now() }])
    } finally {
      setTyping(false)
    }
  }

  const agent = AGENTS.find(a => a.id === activeAgent)!
  const agentMessages = messages.filter(m => m.agent === activeAgent)

  return (
    <div className="max-w-6xl mx-auto p-6">
      <div className="mb-6">
        <h1 className="text-2xl font-bold mb-1">Panel de Chat Multi-Agente</h1>
        <p className="text-muted">Chat en tiempo real con agentes IA especializados via Gemini API</p>
      </div>

      {/* API Key */}
      {!hasKey && (
        <div className="bg-card border border-border rounded-xl p-4 mb-4">
          <div className="flex items-center gap-2 text-sm text-muted mb-3">
            <Key size={16} />
            Necesitas una API key de Gemini. <a href="https://aistudio.google.com/apikey" target="_blank" rel="noopener noreferrer" className="text-accent inline-flex items-center gap-1">Obtener gratis <ExternalLink size={12} /></a>
          </div>
          <div className="flex gap-2">
            <input
              type={showKey ? 'text' : 'password'}
              placeholder="AIza..."
              value={apiKey}
              onChange={e => setApiKey(e.target.value)}
              onBlur={saveKey}
              onKeyDown={e => e.key === 'Enter' && saveKey()}
              className="flex-1 px-3 py-2 rounded-lg bg-bg border border-border text-white text-sm font-mono focus:outline-none focus:border-accent"
            />
            <button onClick={() => setShowKey(!showKey)} className="px-2 text-muted hover:text-white transition-colors">
              {showKey ? <EyeOff size={16} /> : <Eye size={16} />}
            </button>
          </div>
        </div>
      )}

      {/* Chat layout */}
      <div className="grid grid-cols-[240px_1fr] border border-border rounded-xl overflow-hidden h-[70vh] min-h-[450px]">
        {/* Sidebar */}
        <div className="bg-card border-r border-border flex flex-col p-3 gap-2">
          <div className="flex justify-between items-center mb-1">
            <h3 className="text-sm font-semibold">Agentes</h3>
            <button
              onClick={() => setConnected(!connected)}
              className={`flex items-center gap-1 text-[0.7rem] font-semibold px-2 py-0.5 rounded-full ${connected ? 'bg-green-500/15 text-green-500' : 'bg-red-500/15 text-red-500'}`}
            >
              {connected ? <Wifi size={12} /> : <WifiOff size={12} />}
              {connected ? 'Online' : 'Offline'}
            </button>
          </div>

          {AGENTS.map(a => (
            <button
              key={a.id}
              onClick={() => setActiveAgent(a.id)}
              className={`flex items-start gap-2.5 p-2.5 rounded-lg text-left transition-all ${activeAgent === a.id ? 'bg-accent-glow border border-accent' : 'border border-transparent hover:bg-white/[0.03]'}`}
            >
              <span className="w-2 h-2 rounded-full mt-1.5 shrink-0" style={{ background: a.color }} />
              <div>
                <strong className="text-sm block">{a.name}</strong>
                <span className="text-[0.7rem] text-muted">{a.desc}</span>
              </div>
            </button>
          ))}

          <button onClick={() => setMessages([])} className="mt-auto flex items-center justify-center gap-1.5 px-3 py-1.5 text-xs text-muted border border-border rounded-lg hover:text-white hover:border-muted transition-colors">
            <Trash2 size={12} /> Limpiar
          </button>
        </div>

        {/* Main chat */}
        <div className="flex flex-col bg-bg">
          {/* Top bar */}
          <div className="flex items-center gap-2 px-4 py-2.5 border-b border-border text-sm">
            <span className="w-2 h-2 rounded-full" style={{ background: agent.color }} />
            <strong>{agent.name}</strong>
            <span className="ml-auto text-xs text-muted">{connected ? 'Conectado' : 'Desconectado'}</span>
          </div>

          {/* Messages */}
          <div ref={scrollRef} className="flex-1 overflow-y-auto p-4 flex flex-col gap-3">
            {agentMessages.length === 0 && !typing && (
              <div className="flex flex-col items-center justify-center h-full gap-2 text-muted text-sm">
                <Bot size={32} />
                <p>Escribe un mensaje para hablar con {agent.name}</p>
              </div>
            )}
            {agentMessages.map(m => (
              <div key={m.id} className={`flex gap-2 max-w-[80%] ${m.role === 'user' ? 'self-end flex-row-reverse' : ''}`}>
                <div className={`w-7 h-7 min-w-[28px] rounded-full flex items-center justify-center border ${m.role === 'user' ? 'bg-accent border-accent text-white' : 'bg-card border-border text-muted'}`}>
                  {m.role === 'user' ? <User size={13} /> : <Bot size={13} />}
                </div>
                <div className={`rounded-xl px-3 py-2 ${m.role === 'user' ? 'bg-accent-glow border border-accent' : 'bg-card border border-border'}`}>
                  <p className="text-sm leading-relaxed">{m.text}</p>
                  <span className="text-[0.65rem] text-muted block mt-1">{m.time}</span>
                </div>
              </div>
            ))}
            {typing && (
              <div className="flex gap-2">
                <div className="w-7 h-7 min-w-[28px] rounded-full flex items-center justify-center bg-card border border-border text-muted">
                  <Bot size={13} />
                </div>
                <div className="bg-card border border-border rounded-xl px-3 py-2 flex gap-1 items-center">
                  {[0, 1, 2].map(i => (
                    <span key={i} className="w-1.5 h-1.5 rounded-full bg-muted" style={{ animation: `typing 1.2s ease-in-out infinite ${i * 0.2}s` }} />
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Input */}
          <div className="flex gap-2 px-4 py-3 border-t border-border">
            <input
              value={input}
              onChange={e => setInput(e.target.value)}
              onKeyDown={e => e.key === 'Enter' && sendMessage()}
              placeholder={!hasKey ? 'Introduce tu API key arriba' : connected ? 'Escribe un mensaje...' : 'Desconectado'}
              disabled={!connected || !hasKey}
              className="flex-1 px-3 py-2 rounded-lg bg-card border border-border text-white text-sm focus:outline-none focus:border-accent disabled:opacity-50"
            />
            <button
              onClick={sendMessage}
              disabled={!connected || !input.trim() || !hasKey || typing}
              className="px-3 py-2 rounded-lg bg-accent text-white hover:bg-accent-hover transition-colors disabled:opacity-40"
            >
              <Send size={16} />
            </button>
          </div>
        </div>
      </div>
    </div>
  )
}
