import { Link, useLocation } from 'react-router-dom'
import { Code2 } from 'lucide-react'

export default function Navbar() {
  const { pathname, hash } = useLocation()
  const isHome = pathname === '/'

  const linkCls = (active: boolean) =>
    `text-sm font-medium transition-colors ${active ? 'text-accent' : 'text-muted hover:text-accent'}`

  return (
    <nav className="sticky top-0 z-50 flex items-center justify-between px-6 py-3 border-b border-border bg-bg/80 backdrop-blur-xl">
      <Link to="/" className="flex items-center gap-2 text-lg font-bold text-white hover:text-accent transition-colors no-underline">
        <Code2 size={22} /> MSL
      </Link>
      <div className="flex items-center gap-5">
        {isHome ? (
          <>
            <a href="#proyectos" className={linkCls(hash === '#proyectos')}>Proyectos</a>
            <a href="#sobre-mi" className={linkCls(hash === '#sobre-mi')}>Sobre mi</a>
            <a href="#contacto" className={linkCls(hash === '#contacto')}>Contacto</a>
          </>
        ) : (
          <Link to="/" className={linkCls(false)}>Inicio</Link>
        )}
        <Link to="/ocr" className={linkCls(pathname === '/ocr')}>OCR Demo</Link>
      </div>
    </nav>
  )
}
